package br.senai.br.devpag.model;

import br.senai.br.devpag.enums.Funcao;
import br.senai.br.devpag.repository.RoleRepository;
import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;
import lombok.Data;

@Entity
//determina que R = Responsavel no tipo de pessoa
@DiscriminatorValue(value = "F")
@Data
public class Funcionario extends Pessoa{

    public static final String ROLE_ADMINISTRADOR = "ADMINISTRADOR";
    public static final String ROLE_PORTARIA = "PORTARIA";

    private Funcao funcao;

    public void addRole(RoleRepository roleRepository) {
        if (this.funcao.equals(Funcao.ADMINISTRADOR)) {
            Role role = roleRepository.findByName(ROLE_ADMINISTRADOR);
            this.getUser().getRoles().add(role);
        } else if (this.funcao.equals(Funcao.PORTARIA)) {
            Role role = roleRepository.findByName(ROLE_PORTARIA);
            this.getUser().getRoles().add(role);
        }
    }

}
