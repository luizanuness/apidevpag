package br.senai.br.devpag.controller;

import br.senai.br.devpag.enums.StatusSolicitacao;
import br.senai.br.devpag.model.Responsavel;
import br.senai.br.devpag.model.Solicitacao;
import br.senai.br.devpag.repository.ResponsavelRepository;
import br.senai.br.devpag.repository.SolicitacaoRepository;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
@RequestMapping("/responsavel")
public class ResponsavelController {

    @GetMapping("/homeResp")
    public String homeResp() {
        return "responsavel/home"; // Página inicial do responsável
    }

    @Autowired
    private SolicitacaoRepository solicitacaoRepository;

    @Autowired
    private ResponsavelRepository responsavelRepository;

    // Página inicial do responsável com suas solicitações
    @GetMapping("/home")
    public String responsavelHome(Model model) {
        // Recupera o nome de usuário (e-mail) do usuário autenticado
        UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        String username = userDetails.getUsername();

        // Recupera o responsável associado ao e-mail do usuário autenticado
        Responsavel responsavel = responsavelRepository.findByEmail(username);

        // Se o responsável não for encontrado, exibe erro
        if (responsavel == null) {
            model.addAttribute("erro", "Responsável não encontrado!");
            return "/responsavel/home";
        }

        // Busca todas as solicitações associadas ao responsável
        List<Solicitacao> solicitacaos = solicitacaoRepository.findByResponsavelId(responsavel.getId());
        model.addAttribute("solicitacaos", solicitacaos);

        return "responsavel/homeResp";
    }

    // Listagem de Responsáveis
    @GetMapping
    public String listagem(Model model){
        List<Responsavel> listaResponsaveis = responsavelRepository.findAll();
        model.addAttribute("responsaveis", listaResponsaveis);
        return "responsavel/listagem";
    }

    // Página para cadastrar um novo responsável
    @GetMapping("/novo")
    public String cadastrar(Model model){
        model.addAttribute("responsavel", new Responsavel());
        return "responsavel/form-inserir";
    }

    // Salvar novo responsável
    @PostMapping("/salvar")
    public String salvarResponsavel(@Valid Responsavel responsavel,
                                    BindingResult result,
                                    RedirectAttributes attributes){
        if (result.hasErrors()){
            return "responsavel/form-inserir";
        }
        if (errosPersonalizadosInsercao(responsavel, result).hasErrors()){
            return "responsavel/form-inserir";
        }
        responsavelRepository.save(responsavel);
        attributes.addFlashAttribute("mensagem", "Responsável salvo!");
        return "redirect:/responsavel";
    }

    // Página para alterar dados do responsável
    @GetMapping ("/alterar/{id}")
    public String alterar(Model model, @PathVariable Long id){
        Responsavel responsavel = responsavelRepository.findById(id).get();
        model.addAttribute("responsavel", responsavel);
        return "responsavel/alterar";
    }

    // Excluir responsável
    @GetMapping("/excluir/{id}")
    public String excluir(@PathVariable Long id, RedirectAttributes redirectAttributes){
        Responsavel responsavel = responsavelRepository.findById(id).get();
        responsavelRepository.delete(responsavel);
        redirectAttributes.addFlashAttribute("mensagem", "Responsável excluído!");
        return "redirect:/responsavel";
    }

    // Verifica se já existe e-mail ou CPF de responsável
    public BindingResult errosPersonalizadosInsercao(Responsavel responsavel, BindingResult result){
        // Verifica e-mail já cadastrado
        if(responsavelRepository.findByEmail(responsavel.getEmail()) != null){
            result.rejectValue("email", "email.existente", "E-mail já cadastrado");
        }
        // Verifica CPF já cadastrado
        if (responsavelRepository.findByCpf(responsavel.getCpf()) != null){
            result.rejectValue("cpf", "cpf.existente", "CPF já cadastrado");
        }

        return result;
    }

    // Página inicial de Responsável com as solicitações associadas
    @GetMapping("/responsavel/homeResp")
    public String homeResponsavel(Model model){
        UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        String username = userDetails.getUsername();

        // Buscar responsável pelo e-mail
        Responsavel responsavel = responsavelRepository.findByEmail(username);

        // Se o responsável não for encontrado, exibe erro
        if (responsavel == null){
            model.addAttribute("erro", "Responsável não encontrado!");
            return "responsavel/homeResp";
        }

        // Buscar as solicitações do responsável
        List<Solicitacao> solicitacaos = solicitacaoRepository.findByResponsavelId(responsavel.getId());

        model.addAttribute("solicitacaos", solicitacaos);

        return "responsavel/homeResp";
    }
}
