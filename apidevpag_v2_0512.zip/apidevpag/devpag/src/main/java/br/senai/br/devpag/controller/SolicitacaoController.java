package br.senai.br.devpag.controller;

import br.senai.br.devpag.enums.EnumAutorizadoSaida;
import br.senai.br.devpag.enums.StatusSolicitacao;
import br.senai.br.devpag.model.*;
import br.senai.br.devpag.repository.AlunoRepository;
import br.senai.br.devpag.repository.ResponsavelRepository;
import br.senai.br.devpag.repository.SolicitacaoRepository;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/solicitacao")
public class SolicitacaoController {

    @Autowired
    private SolicitacaoRepository solicitacaoRepository;
    @Autowired
    private ResponsavelRepository responsavelRepository;
    @Autowired
    private AlunoRepository alunoRepository;


    // Exibe a página do formulário de solicitação
    @GetMapping("/solicitacaoResp")
    public String exibirFormularioSolicitacao(Model model) {
        // recupera o usuário logado
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        User user = (User) auth.getPrincipal();

        Long id = user.getId();

        Responsavel responsavel = responsavelRepository.findByUserId(id);
        model.addAttribute("alunos", responsavel.getAlunos());
        model.addAttribute("responsavel", responsavel);
        model.addAttribute("solicitacao", new Solicitacao());
        return "responsavel/solicitacaoResp";
    }


    // Responsável faz solicitação
    @PostMapping("/salvar")
    public String salvarSolicitacao(@ModelAttribute @Valid Solicitacao solicitacao, BindingResult bindingResult, Authentication authentication) {
        User usuario = (User) authentication.getPrincipal();

        if (!usuario.isResponsavel()) {
            return "redirect:/access-denied";
        }

        Responsavel responsavel = responsavelRepository.findByUser(usuario);
        solicitacao.setResponsavel(responsavel);
        solicitacao.setStatus(StatusSolicitacao.PENDENTE);
        solicitacao.setAutorizadoSaida(EnumAutorizadoSaida.NAO);
        solicitacaoRepository.save(solicitacao);

        return "redirect:/responsavel/home";
    }


    @GetMapping("/editar/{id}")
    public String editarSolicitacao(@PathVariable Long id, Model model) {
        Solicitacao solicitacao = solicitacaoRepository.findById(id).orElseThrow(() -> new IllegalArgumentException("ID inválido"));
        model.addAttribute("solicitacao", solicitacao);
        return "responsavel/form-alterar";
    }


    @GetMapping("/excluir/{id}")
    public String excluir(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        try {
            // Verifica se a solicitação existe
            Optional<Solicitacao> solicitacaoOptional = solicitacaoRepository.findById(id);

            if (solicitacaoOptional.isPresent()) {
                solicitacaoRepository.deleteById(id);
                redirectAttributes.addFlashAttribute("mensagem", "Solicitação removida com sucesso!");
            } else {
                redirectAttributes.addFlashAttribute("erro", "Solicitação não encontrada!");
            }
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("erro", "Erro ao remover a solicitação: " + e.getMessage());
        }

        return "redirect:/responsavel/home";
    }



}
