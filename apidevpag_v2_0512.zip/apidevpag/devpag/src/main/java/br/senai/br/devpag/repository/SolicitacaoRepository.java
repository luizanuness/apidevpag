package br.senai.br.devpag.repository;

import br.senai.br.devpag.enums.EnumAutorizadoSaida;
import br.senai.br.devpag.enums.StatusSolicitacao;
import br.senai.br.devpag.model.Responsavel;
import br.senai.br.devpag.model.Solicitacao;
import br.senai.br.devpag.model.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.sql.Date;
import java.util.List;

public interface SolicitacaoRepository extends JpaRepository<Solicitacao, Long> {

    List<Solicitacao> findByResponsavelId(Long responsavelId);
    List<Solicitacao> findByStatus(StatusSolicitacao status);
    List<Solicitacao> findByDtSolicitacao(java.sql.Date data);
    List<Solicitacao> findByResponsavel(User responsavel);
    List<Solicitacao> findByResponsavelUser(User user);
    List<Solicitacao> findByResponsavelAndAutorizadoSaida(User responsavel, EnumAutorizadoSaida autorizadoSaida);
    List<Solicitacao> findByStatusAndAutorizadoSaidaAndAutorizadoPeloAdministradorFalseAndConfirmadoPelaPortariaFalse(StatusSolicitacao status, EnumAutorizadoSaida autorizadoSaida);
    List<Solicitacao> findByResponsavel(Responsavel responsavel);

}
