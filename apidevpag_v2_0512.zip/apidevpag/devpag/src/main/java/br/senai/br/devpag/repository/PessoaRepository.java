package br.senai.br.devpag.repository;

import br.senai.br.devpag.model.Pessoa;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PessoaRepository extends JpaRepository<Pessoa,Long> {
}