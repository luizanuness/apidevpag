package br.senai.br.devpag.controller;


import br.senai.br.devpag.enums.StatusSolicitacao;
import br.senai.br.devpag.model.Administrador;
import br.senai.br.devpag.model.Solicitacao;
import br.senai.br.devpag.repository.AdministradorRepository;
import br.senai.br.devpag.repository.RoleRepository;
import br.senai.br.devpag.repository.SolicitacaoRepository;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/administrador")
public class AdministradorController {

    @GetMapping("/homeAdm")
    public String homeAdm(Model model) {
        List<Solicitacao> solicitacoesPendentes = solicitacaoRepository.findByStatus(StatusSolicitacao.PENDENTE);
        model.addAttribute("solicitacoes", solicitacoesPendentes);
        return "administrador/homeAdm"; // Página inicial do administrador
    }


    @Autowired
    private SolicitacaoRepository solicitacaoRepository;
    @Autowired
    private AdministradorRepository administradorRepository;
    @Autowired
    private RoleRepository roleRepository;


    //lista de adms
    @GetMapping
    public String listagem(Model model){
        List<Administrador> listaAdministradores = administradorRepository.findAll();
        model.addAttribute("administradores", listaAdministradores);
        return "administrador/listagem";
    }


    //adicionar adm
    @GetMapping("/novo")
    public String cadastrar(Model model){
        model.addAttribute("administrador", new Administrador());
        return "administrador/form-inserir";
    }


    //salvar adm no banco
    @PostMapping("/salvar")
    public String salvar(@Valid Administrador administrador,
                         BindingResult result,
                         RedirectAttributes redirectAttributes){
        if (result.hasErrors()){
            return "administrador/form-inserir";
        }
        redirectAttributes.addFlashAttribute("mensagem", "Administrador cadastrado!");
        administradorRepository.save(administrador);
        return "redirect:/cad";
    }


    //direcionar para alterar adm
    @GetMapping ("/alterar/{id}")
    public String alterar(Model model, @PathVariable Long id) {
        Optional<Administrador> administradorOptional = administradorRepository.findById(id);
        if (administradorOptional.isPresent()) {
            model.addAttribute("administrador", administradorOptional.get());
            return "administrador/form-alterar";
        } else {
            return "administrador/alterar";
        }
    }



    @GetMapping("/autorizar/{id}")
    public String autorizarSolicitacao(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        Solicitacao solicitacao = solicitacaoRepository.findById(id).orElseThrow(() -> new IllegalArgumentException("Solicitação não encontrada"));

        // Verifica se a solicitação está PENDENTE
        if (solicitacao.getStatus() == StatusSolicitacao.PENDENTE) {
            solicitacao.setStatus(StatusSolicitacao.AUTORIZADA);
            solicitacaoRepository.save(solicitacao);
            redirectAttributes.addFlashAttribute("mensagem", "Solicitação autorizada com sucesso!");
        } else {
            redirectAttributes.addFlashAttribute("erro", "A solicitação não está no status PENDENTE.");
        }

        return "redirect:/administrador/homeAdm"; // Redireciona para a página inicial do administrador
    }


}

