package br.senai.br.devpag.model;

import br.senai.br.devpag.enums.EnumAutorizadoSaida;
import br.senai.br.devpag.enums.StatusSolicitacao;
import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalTime;
import java.time.LocalDate;

@Entity
@JsonIdentityInfo(
        generator = ObjectIdGenerators.PropertyGenerator.class,
        property = "id")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Solicitacao {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", unique = true)
    private Long id;

    // Data e hora da solicitação
    private LocalDate dtSolicitacao;
    private LocalTime hrSolicitacao;

    // Descrição do motivo
    private String dsMotivo;

    // Enum de autorização de saída (Sim ou Não)
    @Enumerated(EnumType.STRING)
    private EnumAutorizadoSaida autorizadoSaida;

    // Status da solicitação
    @Enumerated(EnumType.STRING)
    private StatusSolicitacao status;

    // Relacionamento com o Aluno
    @ManyToOne
    private Aluno aluno;

    // Relacionamento com o Responsável
    @ManyToOne
    private Responsavel responsavel;

    // Status de confirmação pela portaria
    private boolean confirmadoPelaPortaria;

    // Novo campo para verificação de autorização pelo administrador (booleano)
    private boolean autorizadoPeloAdministrador;
}
