package br.senai.br.devpag.controller;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class AlunoControllerTest2 {

    @BeforeEach
    void setUp() {
    }

    @AfterEach
    void tearDown() {
    }

    @Test
    void listar() {
    }

    @Test
    void formInserir() {
    }

    @Test
    void salvar() {
    }

    @Test
    void formAlterar() {
    }

    @Test
    void exluir() {
    }

    @Test
    void addResponsavel() {
    }

    @Test
    void removeResponsavel() {
    }
}