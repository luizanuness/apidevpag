package br.senai.br.devpag;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;

@SpringBootApplication
@EntityScan(basePackages = "br.senai.br.devpag.model") // Adicione este pacote para garantir que as entidades sejam escaneadas
public class DevpagApplication {

	public static void main(String[] args) {
		SpringApplication.run(DevpagApplication.class, args);
	}

}
