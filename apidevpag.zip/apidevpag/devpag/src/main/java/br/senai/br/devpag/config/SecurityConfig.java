package br.senai.br.devpag.config;

import br.senai.br.devpag.service.UserService;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityCustomizer;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    private final UserService userService;

    // Construtor com injeção de dependência para o UserService (não está sendo usado diretamente aqui, mas pode ser útil em autenticação personalizada)
    public SecurityConfig(UserService userService) {
        this.userService = userService;
    }

    // Bean para codificação de senhas com BCrypt
    @Bean
    public BCryptPasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    // Ignorar URLs específicas, como os arquivos estáticos
    @Bean
    public WebSecurityCustomizer webSecurityCustomizer() {
        return (web) -> web.ignoring()
                .requestMatchers("/assets/**");  // Ignorar assets (CSS, JS, imagens)
    }

    // Configuração principal de segurança para URLs e login
    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
                // Configuração de autorização para rotas
                .authorizeHttpRequests(authorizeRequests -> authorizeRequests
                        .requestMatchers("/login/**", "/login").permitAll()  // Permite acesso livre ao login
                        .requestMatchers("/aluno/form-inserir", "/aluno/alterar").hasRole("ADMINISTRADOR")  // Acesso restrito para ADMINISTRADOR
                        .requestMatchers("/administrador/**").hasRole("ADMINISTRADOR")  // Acesso restrito para ADMINISTRADOR
                        .requestMatchers("/portaria/**").hasRole("PORTARIA")  // Acesso restrito para PORTARIA
                        .requestMatchers("/responsavel/**").hasRole("RESPONSAVEL")  // Acesso restrito para RESPONSÁVEL
                        .anyRequest().authenticated()  // Todas as outras rotas exigem autenticação
                )
                // Configuração do formulário de login
                .formLogin(form -> form
                        .loginPage("/login")  // Página de login personalizada
                        .loginProcessingUrl("/login")  // URL que processa o login
                        .failureUrl("/login?error=true")  // Página de erro em caso de falha no login
                        .permitAll()  // Permitir acesso à página de login
                        .successHandler(customAuthenticationSuccessHandler())  // Handler de sucesso para redirecionamento pós-login
                )
                // Configuração do logout
                .logout(logout -> logout
                        .logoutRequestMatcher(new AntPathRequestMatcher("/logout"))  // URL para requisição de logout
                        .logoutSuccessUrl("/login")  // Redirecionamento para a página de login após logout
                );

        return http.build();
    }

    // Configuração do AuthenticationSuccessHandler para redirecionamento após login
    @Bean
    public AuthenticationSuccessHandler customAuthenticationSuccessHandler() {
        return (request, response, authentication) -> {
            // Log para verificar as roles do usuário
            authentication.getAuthorities().forEach(grantedAuthority ->
                    System.out.println("Role do usuário: " + grantedAuthority.getAuthority())
            );

            // Redireciona o usuário para a página correta com base na role
            if (authentication.getAuthorities().stream()
                    .anyMatch(grantedAuthority -> grantedAuthority.getAuthority().equals("ROLE_ADMINISTRADOR"))) {
                response.sendRedirect("/administrador/homeAdm");  // Redireciona para a página do administrador
            } else if (authentication.getAuthorities().stream()
                    .anyMatch(grantedAuthority -> grantedAuthority.getAuthority().equals("ROLE_PORTARIA"))) {
                response.sendRedirect("/portaria/homePort");  // Redireciona para a página da portaria
            } else if (authentication.getAuthorities().stream()
                    .anyMatch(grantedAuthority -> grantedAuthority.getAuthority().equals("ROLE_RESPONSAVEL"))) {
                response.sendRedirect("/responsavel/homeResp");  // Redireciona para a página do responsável
            } else {
                // Caso não tenha role reconhecida, redireciona para uma página padrão ou de erro
                response.sendRedirect("/inicio/index");
            }
        };
    }
}
