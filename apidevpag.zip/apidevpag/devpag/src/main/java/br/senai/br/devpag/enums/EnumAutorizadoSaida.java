package br.senai.br.devpag.enums;

import lombok.Getter;

@Getter
public enum EnumAutorizadoSaida {

    SIM("Sim"),
    NAO("Não");

    private final String descricao;

    EnumAutorizadoSaida(String descricao){
        this.descricao = descricao;
    }

}
