package br.senai.br.devpag.controller;

import br.senai.br.devpag.enums.EnumAutorizadoSaida;
import br.senai.br.devpag.enums.StatusSolicitacao;
import br.senai.br.devpag.model.Responsavel;
import br.senai.br.devpag.model.Solicitacao;
import br.senai.br.devpag.model.User;
import br.senai.br.devpag.repository.ResponsavelRepository;
import br.senai.br.devpag.repository.SolicitacaoRepository;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@Controller
@RequestMapping("/solicitacao")
public class SolicitacaoController {

    @Autowired
    private SolicitacaoRepository solicitacaoRepository;
    @Autowired
    private ResponsavelRepository responsavelRepository;

    // Responsável faz solicitação
    @PostMapping("/salvar")
    public String salvarSolicitacao(@ModelAttribute @Valid Solicitacao solicitacao, BindingResult bindingResult, Authentication authentication) {
        User usuario = (User) authentication.getPrincipal();

        // Verifica se o usuário é um Responsável
        if (!usuario.isResponsavel()) {
            return "redirect:/access-denied";  // Redireciona se não for responsável
        }

        Responsavel responsavel = responsavelRepository.findByUser(usuario);
        solicitacao.setResponsavel(responsavel);
        solicitacao.setStatus(StatusSolicitacao.PENDENTE);
        solicitacao.setAutorizadoSaida(EnumAutorizadoSaida.NAO);
        solicitacaoRepository.save(solicitacao);

        // Após salvar a solicitação, redireciona para a página de solicitação (responsavel/solicitacaoResp)
        return "redirect:/responsavel/solicitacaoResp";  // Redireciona para a página de solicitação
    }


    // Admin autoriza solicitação
    @PostMapping("/autorizar/{id}")
    public String autorizarSaidaAdministrador(@PathVariable Long id, Authentication authentication) {
        User usuario = (User) authentication.getPrincipal();

        // Verifica se o usuário é admin
        if (!usuario.isAdmin()) {
            return "redirect:/access-denied";  // Redireciona se não for admin
        }

        Solicitacao solicitacao = solicitacaoRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Solicitação não encontrada"));

        // Atualiza status
        solicitacao.setStatus(StatusSolicitacao.AUTORIZADA);
        solicitacao.setAutorizadoSaida(EnumAutorizadoSaida.SIM);
        solicitacaoRepository.save(solicitacao);

        return "redirect:/admin/home";  // Redireciona para a home do admin
    }

    // Portaria confirma saída
    @PostMapping("/confirmar/{id}")
    public String confirmarSaidaPortaria(@PathVariable Long id, Authentication authentication) {
        User usuario = (User) authentication.getPrincipal();

        // Verifica se o usuário tem a role de Portaria
        if (!usuario.isPortaria()) {
            return "redirect:/access-denied";  // Redireciona se não for portaria
        }

        Solicitacao solicitacao = solicitacaoRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Solicitação não encontrada"));

        // Confirma a solicitação
        solicitacao.setStatus(StatusSolicitacao.CONFIRMADA);
        solicitacao.setConfirmadoPelaPortaria(true);
        solicitacaoRepository.save(solicitacao);

        return "redirect:/portaria/home";  // Redireciona para a home da portaria
    }

    // Filtra solicitações por data
    @GetMapping("/filtro")
    public String filtrarSolicitacoes(@RequestParam LocalDate data, Model model, Authentication authentication) {
        User usuario = (User) authentication.getPrincipal();

        // Verifica se o usuário tem a role de Admin ou Portaria
        if (!usuario.isAdmin() && !usuario.isPortaria()) {
            return "redirect:/access-denied";  // Redireciona se não for admin ou portaria
        }

        List<Solicitacao> solicitacoes = solicitacaoRepository.findByDtSolicitacao(java.sql.Date.valueOf(data));
        model.addAttribute("solicitacoes", solicitacoes);
        return "solicitacao/lista";  // Retorna para a página de lista de solicitações
    }

    // Exibe histórico de solicitações do responsável
    @GetMapping("/historico")
    public String listarHistoricoSolicitacoes(Model model, Authentication authentication) {
        User usuario = (User) authentication.getPrincipal();

        // Verifica se o usuário é responsável
        if (!usuario.isResponsavel()) {
            return "redirect:/access-denied";  // Redireciona se não for responsável
        }

        // Recupera as solicitações do responsável com autorizadoSaida == NAO
        List<Solicitacao> solicitacoes = solicitacaoRepository.findByResponsavelAndAutorizadoSaida(usuario, EnumAutorizadoSaida.NAO);

        // Adiciona a lista de solicitações ao modelo
        model.addAttribute("solicitacoes", solicitacoes);

        // Adiciona atributo para verificar se o histórico está vazio
        model.addAttribute("historicoVazio", solicitacoes.isEmpty());

        // Exibe a página de histórico
        return "responsavel/historico";
    }

    // Exibe solicitações pendentes
    @GetMapping("/pendentes")
    public String listarSolicitacoesPendentes(Model model, Authentication authentication) {
        User usuario = (User) authentication.getPrincipal();

        // Verifica se o usuário é admin ou portaria
        if (!usuario.isAdmin() && !usuario.isPortaria()) {
            return "redirect:/access-denied";  // Redireciona se não for admin ou portaria
        }

        // Recupera as solicitações pendentes com autorizadoSaida == NAO
        List<Solicitacao> solicitacoesPendentes = solicitacaoRepository.findByStatusAndAutorizadoSaidaAndAutorizadoPeloAdministradorFalseAndConfirmadoPelaPortariaFalse(StatusSolicitacao.PENDENTE, EnumAutorizadoSaida.NAO);

        // Adiciona as solicitações pendentes ao modelo
        model.addAttribute("solicitacoesPendentes", solicitacoesPendentes);

        // Adiciona atributo para verificar se não há pendências
        model.addAttribute("solicitacoesPendentesVazias", solicitacoesPendentes.isEmpty());

        // Exibe as solicitações pendentes
        return "solicitacao/pendentes";
    }
}
