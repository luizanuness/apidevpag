package br.senai.br.devpag.repository;

import br.senai.br.devpag.model.Portaria;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PortariaRepository extends JpaRepository<Portaria,Long> {
}
