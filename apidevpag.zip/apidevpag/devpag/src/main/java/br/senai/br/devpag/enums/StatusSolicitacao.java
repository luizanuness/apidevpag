package br.senai.br.devpag.enums;

import lombok.Getter;

@Getter
public enum StatusSolicitacao {

    PENDENTE,
    AUTORIZADA,
    CONFIRMADA,
    NAO_CONFIRMADA;
}
