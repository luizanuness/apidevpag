package br.senai.br.devpag.controller;
public class CadastroController {
}
