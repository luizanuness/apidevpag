package br.senai.br.devpag.controller;

import br.senai.br.devpag.enums.StatusSolicitacao;
import br.senai.br.devpag.model.Solicitacao;
import br.senai.br.devpag.repository.SolicitacaoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

@Controller
@RequestMapping("/portaria")
public class PortariaController {

    @GetMapping("/homePort")
    public String homePort() {
        return "portaria/homePort"; // Página inicial da portaria
    }

    @Autowired
    private SolicitacaoRepository solicitacaoRepository;

    // Método para listar solicitações pendentes na portaria
    @GetMapping("/pendentes")
    public String listarSolicitacoesPendentes(Model model) {
        // Aqui você pode buscar as solicitações pendentes (com base no status ou outras condições)
        List<Solicitacao> solicitacoesPendentes = solicitacaoRepository.findByStatus(StatusSolicitacao.PENDENTE);

        // Adicionando as solicitações pendentes ao modelo
        model.addAttribute("solicitacoesPendentes", solicitacoesPendentes);

        // Retorna a view que exibe a lista
        return "portaria/pendentes";
    }
}
