package br.senai.br.devpag.model;

public enum Serie {
    PRIMEIRO_FUNDAMENTAL("1º Ano do Fundamental"),
    SEGUNDO_FUNDAMENTAL("2º Ano do Fundamental"),
    TERCEIRO_FUNDAMENTAL("3º Ano do Fundamental"),
    QUARTO_FUNDAMENTAL("4º Ano do Fundamental"),
    QUINTO_FUNDAMENTAL("5º Ano do Fundamental"),
    SEXTO_FUNDAMENTAL("6º Ano do Fundamental"),
    SETIMO_FUNDAMENTAL("7º Ano do Fundamental"),
    OITAVO_FUNDAMENTAL("8º Ano do Fundamental"),
    NONO_FUNDAMENTAL("9º Ano do Fundamental"),
    PRIMEIRO_MEDIO("1º Ano do Médio"),
    SEGUNDO_MEDIO("2º Ano do Médio"),
    TERCEIRO_MEDIO("3º Ano do Médio");

    private final String descricao;

    // Construtor para o enum
    Serie(String descricao) {
        this.descricao = descricao;
    }

    public String getDescricao() {
        return descricao;
    }
}
