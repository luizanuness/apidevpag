package br.senai.br.devpag.enums;

import lombok.Getter;

@Getter
public enum Funcao {

    PORTARIA("Portaria"),
    ADMINISTRADOR("Administração");

    private final String descricao;

    Funcao(String descricao){
        this.descricao = descricao;
    }

}
