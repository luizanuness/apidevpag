package br.senai.br.devpag.model;

import br.senai.br.devpag.repository.RoleRepository;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
//determina que R = Responsavel no tipo de pessoa
@DiscriminatorValue(value = "R")
public class Responsavel extends Pessoa{
    public static final String ROLE_RESPONSAVEL = "RESPONSAVEL";

    @OneToOne
    @JoinColumn(name = "user_id")
    private User user;

    public void addRole(RoleRepository roleRepository) {
        Role role = roleRepository.findByName(ROLE_RESPONSAVEL);
        this.getUser().getRoles().add(role);
    }
    @ManyToMany(mappedBy = "responsaveis", targetEntity = Aluno.class, fetch = FetchType.LAZY)
    private List<Aluno> alunos = new ArrayList<>();

}
