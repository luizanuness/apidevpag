package br.senai.br.devpag.controller;

import br.senai.br.devpag.model.Administrador;
import br.senai.br.devpag.model.Pessoa;
import br.senai.br.devpag.model.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping("/login")
public class LoginController {

    @GetMapping
    public String login() {
        return "inicio/login";
    }

    @PostMapping("/login")
    public String loginSubmit(@RequestParam("username") String username, @RequestParam("password") String password, Model model) {
        return "redirect:/inicio/index"; // Página inicial após login
    }
    @GetMapping("/index")
    public String indexPage(Model model, Authentication authentication) {
        User user = (User) authentication.getPrincipal(); // Obtém o usuário autenticado
        String role = user.getAuthorities().toString(); // Obtém a role do usuário

        if (role.contains("ADMINISTRADOR")) {
            return "administrador/homeAdm"; // Página inicial do administrador
        } else if (role.contains("PORTARIA")) {
            return "portaria/homePort"; // Página inicial da portaria
        } else if (role.contains("RESPONSAVEL")) {
            return "responsavel/homeResp"; // Página inicial do responsável
        }

        return "redirect:/inicio/login"; // Caso não tenha role, redireciona para login
    }
}