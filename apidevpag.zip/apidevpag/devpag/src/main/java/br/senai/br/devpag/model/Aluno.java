package br.senai.br.devpag.model;

import br.senai.br.devpag.enums.Serie;
import br.senai.br.devpag.repository.RoleRepository;
import jakarta.persistence.*;
import lombok.*;

import java.util.ArrayList;
import java.util.List;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@DiscriminatorValue(value = "A")
public class Aluno extends Pessoa {
    public static final String ROLE_ALUNO = "ALUNO";

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long matricula;  // Matrícula do aluno

    @ManyToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    @JoinTable(
            name = "alunos_responsaveis",
            joinColumns = @JoinColumn(name = "aluno_id"),
            inverseJoinColumns = @JoinColumn(name = "responsavel_id")
    )
    private List<Responsavel> responsaveis = new ArrayList<>();

    @Enumerated(EnumType.STRING)  // Define que a série será armazenada como um valor do tipo Enum
    private Serie serie;  // Campo para armazenar a série do aluno

    // Método para adicionar um responsável
    public void addResponsavel(Responsavel responsavel) {
        this.responsaveis.add(responsavel);
    }

    // Método para remover um responsável
    public void removeResponsavel(Responsavel responsavel) {
        this.responsaveis.remove(responsavel);
    }

    // Método para adicionar a role de aluno
    public void addRole(RoleRepository roleRepository) {
        // Verifica se o role ALUNO já existe
        Role role = roleRepository.findByName(ROLE_ALUNO);
        if (role != null) {
            this.getUser().getRoles().add(role);
        } else {
            // Se não encontrar o role, pode criar ou lançar erro dependendo do caso
            System.out.println("Role ALUNO não encontrado");
        }
    }
}
